# from django.db.models.signals import post_save
# from django.dispatch import receiver

# from .models.mensagem_email import MensagemEmail


# @receiver(post_save, sender = MensagemEmail)
# def enviar_notificacao(sender, instance, created, **kwargs):
#    if created:
#        instance.enviar()

# Caso precise usar depois
