default_app_config = 'emails.apps.EmailsConfig'
