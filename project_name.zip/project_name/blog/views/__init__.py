from .post import (
    PostView,
    PostDetail
)


__all__ = [
    PostView, 
    PostDetail   
]
