# Itens fixos do breadcrumb que podem ser reutilizados

example = {
    "name": "Example",
    "slug": "example",
    "url_name": "",
}
